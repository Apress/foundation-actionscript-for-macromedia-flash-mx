The final site available here is basically the site as shown at the end of Chapter 13, with a couple of the examples developed earlier in the book (the hangman game and stunZapper game) included as links from the stun:toys and stun:lab pages, to show you that you can link in your own content to the site.

As shown in the book, the site is fully customizable. You can change what the pages link to, their titles, even how many of them there are. You have the FLAs to play around with. 

friends of ED give this site to you to do with as you please. Use it as a framework for your own designs. It provides a starting point for you to create your own exciting creations.

gotoAndPlay.friendsofED
